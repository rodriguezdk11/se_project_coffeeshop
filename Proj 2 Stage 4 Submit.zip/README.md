# Triple Peaks Coffee Shop

This is the final stage of the Sprint 2 project for SE_Project_coffeeshop.

## Project features

- Semantic HTML5
- Flexbox
- Positioning
- Flat BEM file structure
- A custom form
- CSS animation and transform

## Plan on improving the project

I'd like to improve my cadence of adding CSS Styles as the page forms with the different blocks from the brief. I find myself referencing my old projets a lot and I'd like to be more self sufficient with adding in specific styles and HTML.
